<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | Data Aggregation and Filtering](https://github.com/data-bootcamp-v4/lab-dw-data-aggregation-and-filtering).
