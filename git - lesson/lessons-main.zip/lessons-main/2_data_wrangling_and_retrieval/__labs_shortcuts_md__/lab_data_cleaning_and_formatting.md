<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | Data Cleaning and Formatting](https://github.com/data-bootcamp-v4/lab-dw-data-cleaning-and-formatting).
