<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | Data Structuring and Combining](https://github.com/data-bootcamp-v4/lab-dw-data-structuring-and-combining).
