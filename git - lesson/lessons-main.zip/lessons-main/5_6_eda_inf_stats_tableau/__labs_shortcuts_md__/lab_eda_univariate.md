<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | EDA Univariate Analysis](https://github.com/data-bootcamp-v4/lab-eda-univariate/blob/main/lab_eda_univariate.md).
