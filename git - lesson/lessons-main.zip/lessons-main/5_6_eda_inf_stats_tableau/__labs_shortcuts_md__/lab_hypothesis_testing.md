<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | Hypothesis Testing](https://github.com/data-bootcamp-v4/lab-hypothesis-testing.git).
