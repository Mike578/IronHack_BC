<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | EDA Bivariate Analysis](https://github.com/data-bootcamp-v4/lab-eda-bivariate/blob/main/lab_eda_bivariate.md).
