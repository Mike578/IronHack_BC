<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | Intro to Probability](https://github.com/data-bootcamp-v4/lab-intro-probability.git).
