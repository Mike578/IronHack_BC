:::warning
:exclamation: **Do NOT use webpage translators when working on your assessments.** 
:::

<br>

Click here to see the most frequently asked questions related to Qualified assessments and platform: [General Qualified FAQs](https://gist.github.com/ironhack-edu/8133ae98bd932ac1586afc2b7738d220).