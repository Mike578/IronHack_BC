Every day, during project weeks, you will start with this activity. Take a minute to update your colleagues with your progress: 

- _what did you do so far,_ 
- _do you feel on the track, behind or ahead,_ 
- _what’s your plan for today and_ 
- _do you think you’ll have any blockers._