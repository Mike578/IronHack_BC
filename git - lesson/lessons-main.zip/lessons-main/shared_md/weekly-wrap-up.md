In this session you will participate in a stand up with your classmates and teaching team to discuss how the week went.

The teaching team will guide the session and will ask you to reflect on topics such as:

- What your greatest learnings were
- What were some challenges you faced
- Which topics are you finding difficult or need to spend more time reviewing
- How you found the lessons
- How you found the labs
- How you found the quest

You will record your reflections on a "sprint board" for the first 5-10 minutes and then review as a class for the remainder of the session. Your instructor will share an online tool to gather everyone's insights. Some suggested tools include:

- [Miro](https://miro.com/app/)
- [Mural](https://www.mural.co/)
- [Google Sheets](https://www.google.com/sheets/about/)