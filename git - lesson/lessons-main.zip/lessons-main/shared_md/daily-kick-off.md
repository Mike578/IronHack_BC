<!-- Daily KO -->

<!-- ## Introduction -->

During this brief kickoff session, the teacher will go over today's schedule, and provide a quick overview of the content and topics for today's lessons, the goals for the quest and topics of the labs.