<!-- ## Introduction -->

You will have a daily wrap-up with your teaching team and classmates to end the day and answer any questions you might have.

The aim of this session is to briefly check on everyone's progress and answer any remaining questions. It's an ideal time to ask questions and clear up any uncertainties before ending the day.
