<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | SQL Joins](https://github.com/data-bootcamp-v4/lab-sql-joins).
