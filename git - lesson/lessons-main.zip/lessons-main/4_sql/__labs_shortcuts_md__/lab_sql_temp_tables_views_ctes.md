<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | Temporary Tables, Views and CTEs](https://github.com/data-bootcamp-v4/lab-sql-temp-tables-views-ctes).
