<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | MySQL Database Creation](https://github.com/data-bootcamp-v4/lab-sql-mysql-db-creation).
