<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | SQL Basic Queries](https://github.com/data-bootcamp-v4/lab-sql-basic-queries).
