Find the link to the lesson in Jupyter Notebook here:

- [Coding Best Practices](https://github.com/data-bootcamp-v4/lessons/blob/main/1_intro_to_python/quest/self_guided_lessons/1.2_self_guided_good_practices.ipynb)