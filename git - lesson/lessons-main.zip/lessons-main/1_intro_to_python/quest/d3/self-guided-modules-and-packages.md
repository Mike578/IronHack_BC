Find the link to the lesson in Jupyter Notebook here:

- [Modules and Packages](https://github.com/data-bootcamp-v4/lessons/blob/main/1_intro_to_python/quest/self_guided_lessons/1.3_self_guided_modules_packages.ipynb)