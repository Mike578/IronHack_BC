Find the link to the lesson in Jupyter Notebook here:

- [Interpreting Python Errors](https://github.com/data-bootcamp-v4/lessons/blob/main/1_intro_to_python/quest/self_guided_lessons/1.1_self_guided_reading_errors.ipynb)