<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | Lambda, Map, Reduce, Filter](https://github.com/data-bootcamp-v4/lab-python-lambda-map-reduce-filter).
