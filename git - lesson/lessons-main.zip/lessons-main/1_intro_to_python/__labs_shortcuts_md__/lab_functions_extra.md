<br><br>

Labs are stored on GitHub, so follow the link to get there: [Extra Lab | Functions Extended](https://github.com/data-bootcamp-v4/lab-python-functions-extra).
