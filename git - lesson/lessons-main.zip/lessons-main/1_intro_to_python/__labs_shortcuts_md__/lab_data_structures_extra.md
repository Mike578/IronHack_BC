<br><br>

Labs are stored on GitHub, so follow the link to get there: [Extra Lab | Data Structures Extra](https://github.com/data-bootcamp-v4/lab-python-data-structures-extra).
