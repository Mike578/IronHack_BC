<br><br>

Labs are stored on GitHub, so follow the link to get there: [Extra Lab | List, Dict, Set Comprehension Extended](https://github.com/data-bootcamp-v4/lab-python-list-dict-set-comprehension-extra).
