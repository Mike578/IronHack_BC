<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | Data Structures](https://github.com/data-bootcamp-v4/lab-python-data-structures).
