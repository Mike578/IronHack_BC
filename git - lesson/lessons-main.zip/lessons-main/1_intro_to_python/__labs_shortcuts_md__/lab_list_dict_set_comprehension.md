<br><br>

Labs are stored on GitHub, so follow the link to get there: [Lab | List, Dict, Set Comprehension](https://github.com/data-bootcamp-v4/lab-python-list-dict-set-comprehension).
