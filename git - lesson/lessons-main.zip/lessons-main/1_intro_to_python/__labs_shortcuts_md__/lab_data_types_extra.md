<br><br>

Labs are stored on GitHub, so follow the link to get there: [Extra Lab | Data Types Extra](https://github.com/data-bootcamp-v4/lab-python-data-types-extra).
